#include "Git322.h"

Git322::Git322()
{
}

Git322::~Git322()
{
}

void Git322::add()
{
    myList.add();
}

void Git322::remove()
{
    myList.remove();
}

void Git322::print()
{
    myList.print();
}

void Git322::load()
{
    myList.load();
}

void Git322::compare()
{
    myList.compare();
}

void Git322::search()
{
    myList.search();
}
